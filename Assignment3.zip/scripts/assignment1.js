//1 decalre variables using let
let character = "Scorpion";
let charaterAction = "play";
let object = "a red balloon";
let place = "the volcano";
let time = "a very dark night";

// Using const
const occurrence = "a bad dream";

//create the story
console.log("---FUNNY STORY---");
console.log(character + " was at " + place + " on " + time + ".");
console.log("Suddenly " + character + " saw " + object + " and decided to " + charaterAction + " with it.");
console.log("While having fun, the balloon floated too high, and " + character + " panicked! that he fell into " + place );
console.log("Turns out, it was just " + occurrence);

//Experiment with different values
console.log("---Different version of the story---")

//change values to create a different story

character = "Tom"
charaterAction = "kick"
object = "a television with a humanoid body"
place = "house"
time = "a sunny day"

//create the story
console.log("---FUNNY STORY---");
console.log(character + " was at his friends " + place + " on " + time +", that night " + character + " had " + occurrence + ".");
console.log("Suddenly " + character + " saw " + object + " and decided to " + charaterAction + " the thing out of his frends house");
console.log("Turns out, " + character + " was playing VR and threw his friend's television");
